import { useEffect, useMemo, useState } from "react";
import {
  Bot, CheckCircle2, ChevronRight, CircleDollarSign, FileText,
  Lightbulb, ListTodo, LogOut, Menu, Mic, Plus, Send, Settings,
  Sparkles, Wallet, X
} from "lucide-react";
import { supabase } from "./lib/supabase";
import type { ChatMessage, Item, Section } from "./lib/types";

const nav: { id: Section; label: string; icon: any }[] = [
  { id: "overview", label: "Overview", icon: Sparkles },
  { id: "alvin", label: "Alvin", icon: Bot },
  { id: "finance", label: "Finance", icon: Wallet },
  { id: "ideas", label: "Ideas", icon: Lightbulb },
  { id: "notes", label: "Notes", icon: FileText },
  { id: "tasks", label: "Tasks", icon: ListTodo },
];

function formatDate(value: string) {
  return new Intl.DateTimeFormat("id-ID", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }).format(new Date(value));
}

export default function App() {
  const [section, setSection] = useState<Section>("overview");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [items, setItems] = useState<Item[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: "assistant", content: "Halo bro 👋 Gue Alvin. Tulis aja apa yang lagi lu pikirin. Gue masukin dulu ke inbox, lalu gue pahami apakah itu task, note, idea, atau finance." }
  ]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);

  async function loadItems() {
    if (!supabase) return;
    const { data } = await supabase.from("items").select("*").order("created_at", { ascending: false }).limit(100);
    if (data) setItems(data as Item[]);
  }

  useEffect(() => {
    loadItems();
    supabase?.auth.getUser().then(({ data }) => setUserEmail(data.user?.email ?? null));
  }, []);

  async function sendMessage() {
    const text = input.trim();
    if (!text || sending) return;
    setInput("");
    setMessages(m => [...m, { role: "user", content: text }]);
    setSending(true);

    let userId: string | null = null;
    if (supabase) userId = (await supabase.auth.getUser()).data.user?.id ?? null;

    if (supabase && userId) {
      await supabase.from("items").insert({
        user_id: userId,
        content: text,
        item_type: "inbox",
        status: "pending",
        source: "chat"
      });
      await loadItems();
    }

    try {
      const response = await fetch("/api/alvin-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text })
      });
      if (response.ok) {
        const data = await response.json();
        setMessages(m => [...m, { role: "assistant", content: data.reply ?? "Oke, gue proses." }]);
      } else throw new Error("api unavailable");
    } catch {
      const local = classify(text);
      setMessages(m => [...m, { role: "assistant", content: local }]);
    } finally {
      setSending(false);
    }
  }

  function classify(text: string) {
    const t = text.toLowerCase();
    if (/(rb|ribu|rp|rupiah|bayar|beli|belanja|harga|duit|uang)/.test(t))
      return "Masuk inbox dulu. Ini kelihatannya **Finance**. Nanti AI server akan mengekstrak nominal, kategori, dan jenis transaksi.";
    if (/(besok|nanti|harus|deadline|kerjain|kerjakan|ingatkan|jangan lupa)/.test(t))
      return "Masuk inbox dulu. Ini kelihatannya **Task**. AI akan membaca deadline dan konteksnya.";
    if (/(kepikiran|ide|gimana kalau|kayaknya bisa|rencana bisnis)/.test(t))
      return "Masuk inbox dulu. Ini kelihatannya **Idea**. Alvin akan menyimpan konteks aslinya.";
    return "Sudah gue masukin ke inbox. Alvin akan memahami konteksnya dulu sebelum menentukan apakah ini Note, Idea, Task, atau Finance.";
  }

  async function logout() {
    await supabase?.auth.signOut();
    setUserEmail(null);
  }

  const counts = useMemo(() => ({
    all: items.length,
    pending: items.filter(x => x.status === "pending").length,
    tasks: items.filter(x => x.item_type === "task").length,
    notes: items.filter(x => x.item_type === "note").length,
    ideas: items.filter(x => x.item_type === "idea").length,
    finance: items.filter(x => x.item_type === "finance").length
  }), [items]);

  const content = section === "overview"
    ? <Overview counts={counts} items={items} go={setSection} />
    : section === "alvin"
    ? <Chat messages={messages} input={input} setInput={setInput} send={sendMessage} sending={sending} />
    : section === "settings"
    ? <SettingsPanel email={userEmail} logout={logout} />
    : <Collection title={section[0].toUpperCase() + section.slice(1)} items={items.filter(x => x.item_type === section.slice(0, -1) || (section === "finance" && x.item_type === "finance"))} />;

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
        <div className="brand"><div className="brand-mark"><Bot size={21}/></div><div><b>Alvin</b><span>AI Assistant</span></div></div>
        <div className="nav-label">WORKSPACE</div>
        <nav>{nav.map(n => <button key={n.id} className={section === n.id ? "active" : ""} onClick={() => { setSection(n.id); setMobileOpen(false); }}><n.icon size={18}/><span>{n.label}</span></button>)}</nav>
        <div className="sidebar-bottom">
          <button onClick={() => setSection("settings")} className={section === "settings" ? "active" : ""}><Settings size={18}/><span>Settings</span></button>
          <small>{userEmail || "Local demo mode"}</small>
        </div>
      </aside>
      {mobileOpen && <div className="backdrop" onClick={() => setMobileOpen(false)} />}
      <main className="main">
        <header className="topbar"><button className="icon-btn mobile-menu" onClick={() => setMobileOpen(true)}><Menu size={20}/></button><div><div className="eyebrow">PERSONAL COMMAND CENTER</div><h1>{section === "alvin" ? "Talk to Alvin" : section === "overview" ? "Good to see you." : section[0].toUpperCase() + section.slice(1)}</h1></div><button className="avatar"><Bot size={19}/></button></header>
        <div className="page">{content}</div>
      </main>
    </div>
  );
}

function Overview({ counts, items, go }: { counts: any; items: Item[]; go: (s: Section) => void }) {
  return <div className="stack">
    <section className="hero-card">
      <div><div className="pill"><Sparkles size={14}/> Context-aware inbox</div><h2>Tuangin aja isi kepala lu.</h2><p>Alvin menerima semuanya sebagai item mentah, lalu AI memilah konteksnya ke Task, Note, Idea, atau Finance.</p><button className="primary" onClick={() => go("alvin")}>Mulai ngobrol <ChevronRight size={17}/></button></div>
      <div className="hero-orb"><Bot size={72}/></div>
    </section>
    <div className="stat-grid">
      <Stat label="Inbox" value={counts.all} icon={Sparkles}/>
      <Stat label="Pending" value={counts.pending} icon={CheckCircle2}/>
      <Stat label="Tasks" value={counts.tasks} icon={ListTodo}/>
      <Stat label="Finance" value={counts.finance} icon={CircleDollarSign}/>
    </div>
    <section className="panel"><div className="panel-head"><div><h3>Recent items</h3><p>Semua input mentah tetap tersimpan sebagai konteks.</p></div><button className="ghost" onClick={() => go("alvin")}><Plus size={16}/> Add</button></div>
      {items.length === 0 ? <Empty/> : <div className="items">{items.slice(0, 8).map(i => <ItemRow key={i.id} item={i}/>)}</div>}
    </section>
  </div>;
}

function Stat({ label, value, icon: Icon }: any) { return <div className="stat"><div className="stat-icon"><Icon size={18}/></div><div><b>{value}</b><span>{label}</span></div></div>; }

function ItemRow({ item }: { item: Item }) {
  return <div className="item-row"><div className={`type-dot ${item.item_type}`}></div><div className="item-main"><b>{item.content}</b><span>{formatDate(item.created_at)} · {item.item_type === "inbox" ? "Menunggu pemahaman AI" : item.item_type}</span></div><span className={`badge ${item.status}`}>{item.status}</span></div>;
}

function Collection({ title, items }: { title: string; items: Item[] }) {
  return <section className="panel"><div className="panel-head"><div><h3>{title}</h3><p>Data hasil pemilahan konteks Alvin.</p></div></div>{items.length ? <div className="items">{items.map(i => <ItemRow key={i.id} item={i}/>)}</div> : <Empty/>}</section>;
}

function Empty() { return <div className="empty"><Sparkles size={25}/><b>Belum ada data</b><span>Ngobrol dengan Alvin untuk mulai mengisi workspace.</span></div>; }

function Chat({ messages, input, setInput, send, sending }: any) {
  const [listening, setListening] = useState(false);
  function voice() {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;
    const r = new SpeechRecognition();
    r.lang = "id-ID";
    r.onstart = () => setListening(true);
    r.onend = () => setListening(false);
    r.onresult = (e: any) => setInput(e.results[0][0].transcript);
    r.start();
  }
  return <div className="chat-layout"><div className="chat-card"><div className="chat-head"><div className="alvin-avatar"><Bot size={22}/></div><div><b>Alvin</b><span>Context-aware assistant</span></div><span className="online"></span></div>
    <div className="messages">{messages.map((m: ChatMessage, i: number) => <div key={i} className={`message ${m.role}`}><div>{m.content}</div></div>)}{sending && <div className="message assistant"><div className="typing"><i></i><i></i><i></i></div></div>}</div>
    <div className="composer"><textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => {if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}}} placeholder="Contoh: tadi gua beli nasi goreng 20rb..." /><button className={`icon-btn ${listening ? "recording":""}`} onClick={voice}><Mic size={19}/></button><button className="send" onClick={send} disabled={sending || !input.trim()}><Send size={18}/></button></div>
    <div className="composer-hint">{listening ? "Mendengarkan..." : "Enter untuk kirim · Shift + Enter untuk baris baru"}</div></div>
    <div className="chat-side"><div className="mini-card"><Sparkles size={19}/><b>Inbox-first AI</b><p>Input lu tidak langsung dibuang ke tabel kategori. Alvin menyimpan item mentah lalu memahami konteksnya.</p></div><div className="mini-card"><Mic size={19}/><b>Voice</b><p>Gunakan mic browser untuk speech-to-text gratis di browser yang mendukung.</p></div></div>
  </div>;
}

function SettingsPanel({ email, logout }: { email: string | null; logout: () => void }) {
  return <div className="settings-grid"><section className="panel"><h3>Settings</h3><div className="setting-row"><div><b>Account</b><span>{email || "Local demo mode"}</span></div><button className="ghost danger" onClick={logout}><LogOut size={16}/> Sign out</button></div><div className="setting-row"><div><b>Chat wallpaper</b><span>Soft blue — coming soon</span></div><button className="ghost" disabled>Customize</button></div></section></div>;
}